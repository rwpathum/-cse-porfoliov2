# CSE Portfolio Manager — Windows Desktop App
### Colombo Stock Exchange · LKR · Electron Desktop Application

---

## What This Is
A fully installable **Windows desktop application** (.exe installer + portable .exe) for managing your Colombo Stock Exchange portfolio. Built with Electron — the same technology used by VS Code, Slack, and Discord.

---

## Quick Start (Run Without Building)

### Option A — Just run it (development mode)
```cmd
npm install
npm start
```
Requires Node.js 18+ installed.

---

## Build Installable Windows .exe

### Prerequisites
- **Node.js 18+** — https://nodejs.org
- **Windows 10/11** (recommended for building) or any OS with Wine

### Step 1 — Install dependencies
```cmd
cd CSEPortfolioDesktop
npm install
```

### Step 2 — Build installer + portable
```cmd
npm run build:all
```

Output files in `dist/` folder:
| File | Type | Use |
|------|------|-----|
| `CSE Portfolio Setup 1.0.0.exe` | NSIS Installer | Standard Windows installer — installs to Program Files, adds Start Menu & Desktop shortcut, includes uninstaller |
| `CSEPortfolio-Portable-1.0.0.exe` | Portable | Single .exe — run from anywhere, no installation needed |

### Build only installer
```cmd
npm run build
```

### Build only portable
```cmd
npm run build:portable
```

---

## Installing on Windows

### Via Installer (Recommended)
1. Double-click `CSE Portfolio Setup 1.0.0.exe`
2. Choose installation directory (default: `C:\Program Files\CSE Portfolio`)
3. Optionally create Desktop / Start Menu shortcuts
4. Click Install → Finish
5. Launch from Desktop shortcut or Start Menu

### Via Portable
1. Copy `CSEPortfolio-Portable-1.0.0.exe` anywhere (USB drive, Downloads, etc.)
2. Double-click to run — no installation needed
3. Data is saved next to the .exe file

---

## Features

| Feature | Description |
|---------|-------------|
| 📊 **Dashboard** | ASPI + S&P SL20 index strip, 30-day portfolio trend chart, sector allocation, top gainers/losers |
| 📋 **Holdings** | Add/edit/delete holdings, inline CMP update, sortable/searchable table, portfolio summary |
| 📈 **Analytics** | P&L bars, return % comparison, sector bar chart, portfolio trend, health score |
| 💾 **Auto-save** | Holdings persist between sessions via local JSON file |
| 📂 **Import CSV** | File picker dialog — import holdings from CSV file |
| 📤 **Export CSV** | Save Holdings to CSV with native Save dialog |
| ⌨️ **Keyboard Shortcuts** | Ctrl+1/2/3 (tabs), Ctrl+O (import), Ctrl+E (export), F11 (fullscreen), F12 (devtools) |
| 🖥️ **Native menus** | File / View / Help menus with full Windows integration |
| 🔒 **Local data** | All data stored on your computer — no internet required after first launch |

---

## CSV Format

Import/export uses this format:
```csv
symbol,name,qty,avgCost,cmp,sector
COMB.N0000,Commercial Bank of Ceylon PLC,200,112.00,128.50,Banks
JKH.N0000,John Keells Holdings PLC,100,195.00,218.75,Diversified Financials
DIAL.N0000,Dialog Axiata PLC,500,14.20,13.40,Telecommunication
LOLC.N0000,LOLC Holdings PLC,80,520.00,610.00,Diversified Financials
```

### CSE Ticker Format
- `SYMBOL.N0000` — Ordinary voting shares
- `SYMBOL.X0000` — Non-voting shares  
- `SYMBOL.D0000` — Debentures

---

## Data Storage Location
Holdings are saved at:
```
C:\Users\<YourName>\AppData\Roaming\cse-portfolio\holdings.json
```
You can back this file up or copy it between computers.

---

## Project Structure
```
CSEPortfolioDesktop/
├── package.json          — npm config + electron-builder settings
├── src/
│   ├── main.js           — Electron main process (window, menus, IPC, file I/O)
│   ├── preload.js        — Secure bridge between main & renderer
│   └── renderer/
│       ├── index.html    — App entry point
│       ├── styles.css    — Full dark theme (CSE navy + gold)
│       └── app.js        — All UI logic: Dashboard, Holdings, Analytics, modals
├── assets/
│   ├── icon.ico          — Windows icon (multi-resolution)
│   ├── installer.nsh     — NSIS installer customization
│   └── make_icon.py      — Icon generator script
└── dist/                 — Build output (generated)
```

---

## CSE Reference
| Item | Value |
|------|-------|
| Exchange | Colombo Stock Exchange (CSE) |
| MIC Code | XCOL |
| Currency | Sri Lankan Rupee (LKR · රු.) |
| Main Index | All Share Price Index (ASPI) |
| 2nd Index | S&P Sri Lanka 20 (S&P SL20) |
| Time Zone | GMT +5:30 (Asia/Colombo) |
| Trading Days | Monday – Friday |
| Listed Companies | ~284 (as of 2025) |
| Sectors | 20 GICS industry groups |

---

## Troubleshooting

**"Windows protected your PC" SmartScreen warning:**
Click "More info" → "Run anyway". This appears because the installer isn't code-signed. To remove it permanently, purchase a code-signing certificate from DigiCert, Sectigo, etc.

**App won't start:**
```cmd
npm start -- --dev
```
Check the DevTools console (F12) for errors.

**Data file location:**
```
%APPDATA%\cse-portfolio\holdings.json
```

**Build fails on non-Windows machine:**
```cmd
npm install --platform=win32 --arch=x64
npm run build
```
Or use GitHub Actions / a Windows VM for building.

**Icon missing:**
```cmd
python assets/make_icon.py
```

---

## Distribution Checklist

- [ ] Run `npm run build:all`
- [ ] Test `CSE Portfolio Setup 1.0.0.exe` on a clean Windows machine
- [ ] Test `CSEPortfolio-Portable-1.0.0.exe` from USB drive
- [ ] (Optional) Code-sign with `signtool.exe` for no SmartScreen warning
- [ ] Upload installer to Google Drive / OneDrive to share with users
