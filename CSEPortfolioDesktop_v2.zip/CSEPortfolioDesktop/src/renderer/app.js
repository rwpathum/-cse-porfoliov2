/* ============================================================
   CSE Portfolio Manager — Renderer (app.js)
   Colombo Stock Exchange · LKR · Windows Desktop App
   ============================================================ */

'use strict';

// ── Constants ─────────────────────────────────────────────────────────────────
const COLORS = {
  gold:'#C8973A', navy:'#003087', green:'#2E8B57', red:'#C0392B',
  bgCard:'#0e1a2e', textSub:'#7a8fb5', textMuted:'#3a4f6a',
};
const PALETTE = [
  '#C8973A','#1A56B0','#2E8B57','#C0392B','#8E44AD',
  '#16A085','#D35400','#2980B9','#27AE60','#9B59B6',
];
const CSE_SECTORS = [
  'Banks','Diversified Financials','Insurance',
  'Food, Beverage & Tobacco','Food & Staples Retailing',
  'Health Care','Pharmaceuticals & Biotech','Telecommunication',
  'Energy','Materials','Capital Goods','Transportation','Retailing',
  'Consumer Services','Consumer Durables & Apparel',
  'Household & Personal Products','Real Estate','Utilities',
  'Commercial & Professional Services','Automobiles & Components',
];
const SEED = [
  {id:'1',symbol:'COMB.N0000',name:'Commercial Bank of Ceylon PLC',    qty:200, avgCost:112.00,cmp:128.50,sector:'Banks'},
  {id:'2',symbol:'HNB.N0000', name:'Hatton National Bank PLC',         qty:150, avgCost:178.00,cmp:196.25,sector:'Banks'},
  {id:'3',symbol:'JKH.N0000', name:'John Keells Holdings PLC',         qty:100, avgCost:195.00,cmp:218.75,sector:'Diversified Financials'},
  {id:'4',symbol:'DIAL.N0000',name:'Dialog Axiata PLC',                qty:500, avgCost:14.20, cmp:13.40, sector:'Telecommunication'},
  {id:'5',symbol:'LOLC.N0000',name:'LOLC Holdings PLC',                qty:80,  avgCost:520.00,cmp:610.00,sector:'Diversified Financials'},
  {id:'6',symbol:'SAMP.N0000',name:'Sampath Bank PLC',                 qty:180, avgCost:76.50, cmp:88.00, sector:'Banks'},
  {id:'7',symbol:'CINS.N0000',name:'Ceylinco Insurance PLC',           qty:40,  avgCost:1800.00,cmp:2050.00,sector:'Insurance'},
  {id:'8',symbol:'CTC.N0000', name:'Ceylon Tobacco Company PLC',       qty:25,  avgCost:1150.00,cmp:1080.00,sector:'Food, Beverage & Tobacco'},
];

// ── Formatters ────────────────────────────────────────────────────────────────
const fmt   = (n,d=2) => Number(n).toLocaleString('en-LK',{minimumFractionDigits:d,maximumFractionDigits:d});
const fmtLKR= (n) => 'රු.' + fmt(Math.abs(n));
const pct   = (n) => (n>=0?'+':'')+fmt(n,2)+'%';
const plCol = (v) => v>=0 ? COLORS.green : COLORS.red;
const uid   = () => '_' + Math.random().toString(36).slice(2,9);

// ── State ─────────────────────────────────────────────────────────────────────
let holdings  = [...SEED];
let activeTab = 'dashboard';
let chartInstances = {};

// Generate 30-day history
const HISTORY = (() => {
  const a=[]; let v=3800000;
  for(let i=29;i>=0;i--){ v+=(Math.random()-0.42)*90000; a.push(Math.round(v)); }
  return a;
})();

// ── Computed ──────────────────────────────────────────────────────────────────
function enrich(hs) {
  return hs.map(h => {
    const invested = h.qty * h.avgCost;
    const current  = h.qty * h.cmp;
    const pl       = current - invested;
    const plPct    = invested ? (pl/invested)*100 : 0;
    return {...h, invested, current, pl, plPct};
  });
}
function totals(hs) {
  const e = enrich(hs);
  const invested = e.reduce((a,h)=>a+h.invested,0);
  const current  = e.reduce((a,h)=>a+h.current,0);
  const pl = current-invested;
  return {invested, current, pl, plPct: invested?(pl/invested)*100:0};
}
function sectorMap(hs) {
  const m={};
  enrich(hs).forEach(h=>{m[h.sector]=(m[h.sector]||0)+h.current;});
  return Object.entries(m).sort((a,b)=>b[1]-a[1]);
}

// ── Persistence ───────────────────────────────────────────────────────────────
async function save() {
  if(window.electronAPI) await window.electronAPI.saveHoldings(holdings);
}
async function load() {
  if(window.electronAPI) {
    const d = await window.electronAPI.loadHoldings();
    if(d && Array.isArray(d) && d.length) holdings = d;
  }
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function toast(msg, dur=2500) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), dur);
}

// ── Chart helpers ─────────────────────────────────────────────────────────────
function destroyChart(id) {
  if(chartInstances[id]) { chartInstances[id].destroy(); delete chartInstances[id]; }
}
function makeChart(id, config) {
  destroyChart(id);
  const ctx = document.getElementById(id);
  if(!ctx) return;
  chartInstances[id] = new Chart(ctx.getContext('2d'), config);
}

// ── DOM builders ──────────────────────────────────────────────────────────────
function el(tag, attrs={}, children=[]) {
  const e = document.createElement(tag);
  Object.entries(attrs).forEach(([k,v])=>{
    if(k==='class') e.className=v;
    else if(k==='style') Object.assign(e.style,v);
    else if(k.startsWith('on')) e.addEventListener(k.slice(2).toLowerCase(),v);
    else e.setAttribute(k,v);
  });
  children.forEach(c=> typeof c==='string' ? e.append(c) : c && e.appendChild(c));
  return e;
}

// ── BUILD UI ──────────────────────────────────────────────────────────────────
function buildShell() {
  document.getElementById('app').innerHTML = `
    <div id="titlebar">
      <span id="titlebar-logo">CSE <span>Portfolio</span></span>
      <span id="titlebar-sub">COLOMBO STOCK EXCHANGE · LKR</span>
    </div>
    <div id="topbar">
      <div id="market-strip">
        <div class="market-item"><span class="label">ASPI</span><span class="value">23,956.51</span><span class="change up">+1.08%</span></div>
        <div class="market-item"><span class="label">S&P SL20</span><span class="value">4,812.34</span><span class="change up">+0.73%</span></div>
        <div class="market-item"><span class="label">Market Cap</span><span class="value">රු.8.12T</span><span class="change up">LKR</span></div>
        <div class="market-item"><span class="label">Turnover</span><span class="value">රු.4.2Bn</span><span class="change up">Today</span></div>
      </div>
      <nav id="nav">
        <button class="nav-btn active" data-tab="dashboard">📊 Dashboard</button>
        <button class="nav-btn" data-tab="holdings">📋 Holdings</button>
        <button class="nav-btn" data-tab="analytics">📈 Analytics</button>
      </nav>
      <div id="topbar-actions">
        <button class="btn-outline" id="btn-import">↑ Import CSV</button>
        <button class="btn-outline" id="btn-export">↓ Export CSV</button>
        <button class="btn-gold"    id="btn-add">+ Add Holding</button>
      </div>
    </div>
    <div id="main">
      <div class="tab-view active" id="tab-dashboard"></div>
      <div class="tab-view"        id="tab-holdings"></div>
      <div class="tab-view"        id="tab-analytics"></div>
    </div>
    <!-- Modals -->
    <div class="modal-overlay" id="modal-holding">
      <div class="modal-box" id="modal-holding-box"></div>
    </div>
    <div class="modal-overlay" id="modal-csv">
      <div class="modal-box" id="modal-csv-box"></div>
    </div>
    <div class="modal-overlay" id="modal-cmp">
      <div class="modal-box" style="max-width:320px" id="modal-cmp-box"></div>
    </div>
  `;

  // Nav tabs
  document.querySelectorAll('.nav-btn').forEach(btn=>{
    btn.addEventListener('click',()=>switchTab(btn.dataset.tab));
  });
  document.getElementById('btn-add').addEventListener('click',()=>openHoldingModal(null));
  document.getElementById('btn-import').addEventListener('click',importCSV);
  document.getElementById('btn-export').addEventListener('click',exportCSV);

  // Electron menu events
  if(window.electronAPI) {
    window.electronAPI.onMenuImportCsv(()=>importCSV());
    window.electronAPI.onMenuExportCsv(()=>exportCSV());
    window.electronAPI.onMenuTab((t)=>switchTab(t));
  }
}

// ── Tab switching ─────────────────────────────────────────────────────────────
function switchTab(tab) {
  activeTab = tab;
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
  document.querySelectorAll('.tab-view').forEach(v=>v.classList.toggle('active',v.id==='tab-'+tab));
  renderTab(tab);
}

function renderTab(tab) {
  if(tab==='dashboard') renderDashboard();
  if(tab==='holdings')  renderHoldings();
  if(tab==='analytics') renderAnalytics();
}

// ── DASHBOARD ─────────────────────────────────────────────────────────────────
function renderDashboard() {
  const e   = enrich(holdings);
  const t   = totals(holdings);
  const sm  = sectorMap(holdings);
  const maxSector = sm[0]?.[1] || 1;
  const gainers = [...e].sort((a,b)=>b.plPct-a.plPct).slice(0,5);
  const losers  = [...e].sort((a,b)=>a.plPct-b.plPct).slice(0,5);

  document.getElementById('tab-dashboard').innerHTML = `
    <!-- KPIs -->
    <div class="kpi-grid">
      <div class="kpi-card gold-top">
        <div class="kpi-label">Portfolio Value (LKR)</div>
        <div class="kpi-value" style="color:var(--text)">${fmtLKR(t.current)}</div>
        <div class="kpi-sub">${holdings.length} holdings</div>
      </div>
      <div class="kpi-card" style="border-top-color:var(--text-muted)">
        <div class="kpi-label">Cost Basis (LKR)</div>
        <div class="kpi-value" style="color:var(--text-sub)">${fmtLKR(t.invested)}</div>
        <div class="kpi-sub">Total invested</div>
      </div>
      <div class="kpi-card" style="border-top-color:${plCol(t.pl)}">
        <div class="kpi-label">Unrealised P&amp;L</div>
        <div class="kpi-value" style="color:${plCol(t.pl)}">${(t.pl>=0?'+':'-')+fmtLKR(Math.abs(t.pl))}</div>
        <div class="kpi-sub" style="color:${plCol(t.plPct)}">${pct(t.plPct)}</div>
      </div>
      <div class="kpi-card gold-top">
        <div class="kpi-label">ASPI (YTD)</div>
        <div class="kpi-value" style="color:var(--gold)">+61.3%</div>
        <div class="kpi-sub">Benchmark index</div>
      </div>
    </div>

    <!-- Chart + Sectors -->
    <div class="row-2">
      <div class="card">
        <div class="section-label">Portfolio Value — 30 Days (LKR)</div>
        <canvas id="chart-trend" height="180"></canvas>
      </div>
      <div class="card">
        <div class="section-label">Sector Allocation</div>
        ${sm.map(([s,v],i)=>`
          <div class="sector-row">
            <div class="sector-dot" style="background:${PALETTE[i%PALETTE.length]}"></div>
            <span class="sector-name">${s}</span>
            <div class="sector-bar-wrap"><div class="sector-bar-fill" style="width:${(v/maxSector*100).toFixed(1)}%;background:${PALETTE[i%PALETTE.length]}"></div></div>
            <span class="sector-val">${fmtLKR(v)}</span>
            <span class="sector-pct">${((v/t.current)*100).toFixed(1)}%</span>
          </div>`).join('')}
      </div>
    </div>

    <!-- Gainers / Losers -->
    <div class="row-2-equal">
      <div class="card">
        <div class="section-label">🚀 Top Gainers</div>
        ${gainers.map(h=>`
          <div class="mover-row">
            <div>
              <div class="mover-symbol">${h.symbol}</div>
              <div class="mover-sector">${h.sector}</div>
            </div>
            <div>
              <div class="mover-pct" style="color:${COLORS.green}">${pct(h.plPct)}</div>
              <div class="mover-pl">+${fmtLKR(Math.abs(h.pl))}</div>
            </div>
          </div>`).join('')}
      </div>
      <div class="card">
        <div class="section-label">📉 Top Losers</div>
        ${losers.map(h=>`
          <div class="mover-row">
            <div>
              <div class="mover-symbol">${h.symbol}</div>
              <div class="mover-sector">${h.sector}</div>
            </div>
            <div>
              <div class="mover-pct" style="color:${COLORS.red}">${pct(h.plPct)}</div>
              <div class="mover-pl" style="color:var(--text-muted)">-${fmtLKR(Math.abs(h.pl))}</div>
            </div>
          </div>`).join('')}
      </div>
    </div>

    <!-- CSE Info -->
    <div class="cse-info-strip">
      <span style="font-size:9px;color:var(--gold);font-weight:700;letter-spacing:.12em">CSE INFO</span>
      ${[['Exchange','Colombo Stock Exchange'],['MIC','XCOL'],['Currency','LKR (රු.)'],['Time Zone','GMT +5:30'],['Main Index','ASPI'],['Listed','~284 Companies']]
        .map(([k,v])=>`<div class="cse-info-item"><div class="key">${k}</div><div class="val">${v}</div></div>`).join('')}
    </div>
  `;

  // Trend chart
  makeChart('chart-trend',{
    type:'line',
    data:{
      labels: HISTORY.map((_,i)=> i%5===0 ? `d${i+1}` : ''),
      datasets:[{
        data: HISTORY,
        borderColor: COLORS.gold,
        backgroundColor: 'rgba(200,151,58,0.08)',
        borderWidth: 2,
        fill: true,
        tension: 0.4,
        pointRadius: 0,
      }]
    },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{display:false}, tooltip:{
        callbacks:{ label: ctx=>'රු.'+fmt(ctx.raw) },
        backgroundColor:'#0e1a2e', borderColor:'rgba(200,151,58,0.3)', borderWidth:1,
      }},
      scales:{
        x:{ grid:{color:'rgba(255,255,255,0.04)'}, ticks:{color:COLORS.textMuted,font:{size:10}} },
        y:{ grid:{color:'rgba(255,255,255,0.04)'}, ticks:{color:COLORS.textMuted,font:{size:10}, callback:v=>'M'+(v/1e6).toFixed(2)} },
      }
    }
  });
}

// ── HOLDINGS ──────────────────────────────────────────────────────────────────
let holdingsSearch = '';
let holdingsSort   = 'value';

function renderHoldings() {
  const e = enrich(holdings);
  const t = totals(holdings);
  let filtered = e.filter(h=>
    h.symbol.toLowerCase().includes(holdingsSearch.toLowerCase()) ||
    h.name.toLowerCase().includes(holdingsSearch.toLowerCase())
  );
  if(holdingsSort==='value') filtered.sort((a,b)=>b.current-a.current);
  if(holdingsSort==='pl')    filtered.sort((a,b)=>b.pl-a.pl);
  if(holdingsSort==='plPct') filtered.sort((a,b)=>b.plPct-a.plPct);
  if(holdingsSort==='name')  filtered.sort((a,b)=>a.symbol.localeCompare(b.symbol));

  const sm = sectorMap(holdings);

  document.getElementById('tab-holdings').innerHTML = `
    <div id="holdings-toolbar">
      <input id="search-input" placeholder="Search symbol or company…" value="${holdingsSearch}">
      <select id="sort-select">
        <option value="value" ${holdingsSort==='value'?'selected':''}>Sort: Current Value</option>
        <option value="pl"    ${holdingsSort==='pl'   ?'selected':''}>Sort: P&amp;L (LKR)</option>
        <option value="plPct" ${holdingsSort==='plPct'?'selected':''}>Sort: P&amp;L %</option>
        <option value="name"  ${holdingsSort==='name' ?'selected':''}>Sort: Ticker A–Z</option>
      </select>
      <span class="holdings-count">${filtered.length} of ${holdings.length} holdings</span>
    </div>

    <div class="card" style="padding:0;overflow:hidden">
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th style="text-align:left">Ticker / Company</th>
              <th>Sector</th>
              <th>Qty</th>
              <th>Avg Cost</th>
              <th>CMP ✎</th>
              <th>Invested</th>
              <th>Current</th>
              <th>P&amp;L (LKR)</th>
              <th>P&amp;L %</th>
              <th></th>
            </tr>
          </thead>
          <tbody id="holdings-tbody">
            ${filtered.map(h=>{
              const si = sm.findIndex(([s])=>s===h.sector);
              const col = PALETTE[si%PALETTE.length];
              const plClass = h.pl>=0?'td-green':'td-red';
              return `<tr>
                <td>
                  <div class="td-symbol">${h.symbol}</div>
                  <div class="td-name" title="${h.name}">${h.name}</div>
                </td>
                <td><span class="badge" style="color:${col};background:${col}22;border-color:${col}55">${h.sector}</span></td>
                <td class="td-mono">${h.qty}</td>
                <td class="td-mono" style="color:var(--text-sub)">රු.${fmt(h.avgCost)}</td>
                <td><span class="cmp-edit" data-id="${h.id}" data-cmp="${h.cmp}">රු.${fmt(h.cmp)}</span></td>
                <td class="td-mono" style="color:var(--text-muted)">රු.${fmt(h.invested)}</td>
                <td class="td-mono">රු.${fmt(h.current)}</td>
                <td class="${plClass}">${h.pl>=0?'+':'-'}රු.${fmt(Math.abs(h.pl))}</td>
                <td class="${plClass}" style="font-weight:800">${pct(h.plPct)}</td>
                <td>
                  <button class="action-btn edit"   data-id="${h.id}">Edit</button>
                  <button class="action-btn delete"  data-id="${h.id}">×</button>
                </td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Summary footer -->
    <div class="card gold-top">
      <div class="summary-grid">
        ${[
          ['Total Invested', fmtLKR(t.invested), 'var(--text-sub)'],
          ['Current Value',  fmtLKR(t.current),  'var(--text)'],
          ['Unrealised P&L', (t.pl>=0?'+':'-')+fmtLKR(Math.abs(t.pl)), plCol(t.pl)],
          ['Overall Return', pct(t.plPct), plCol(t.plPct)],
        ].map(([l,v,c])=>`
          <div class="summary-cell">
            <div class="label">${l}</div>
            <div class="value" style="color:${c}">${v}</div>
          </div>`).join('')}
      </div>
    </div>
  `;

  // Events
  document.getElementById('search-input').addEventListener('input',e=>{holdingsSearch=e.target.value;renderHoldings();});
  document.getElementById('sort-select').addEventListener('change',e=>{holdingsSort=e.target.value;renderHoldings();});

  document.querySelectorAll('.cmp-edit').forEach(el=>{
    el.addEventListener('click',()=>openCmpModal(el.dataset.id, el.dataset.cmp));
  });
  document.querySelectorAll('.action-btn.edit').forEach(btn=>{
    btn.addEventListener('click',()=>openHoldingModal(holdings.find(h=>h.id===btn.dataset.id)));
  });
  document.querySelectorAll('.action-btn.delete').forEach(btn=>{
    btn.addEventListener('click',()=>deleteHolding(btn.dataset.id));
  });
}

// ── ANALYTICS ─────────────────────────────────────────────────────────────────
function renderAnalytics() {
  const e   = enrich(holdings);
  const t   = totals(holdings);
  const sm  = sectorMap(holdings);
  const maxPL  = Math.max(...e.map(h=>Math.abs(h.pl)),1);
  const maxPct = Math.max(...e.map(h=>Math.abs(h.plPct)),1);

  document.getElementById('tab-analytics').innerHTML = `
    <!-- Summary row -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:14px">
      ${[
        ['Holdings', holdings.length, COLORS.gold],
        ['Invested', fmtLKR(t.invested), COLORS.textSub],
        ['Current',  fmtLKR(t.current),  '#e8f0fb'],
      ].map(([l,v,c])=>`
        <div class="card" style="padding:14px;border-top:2px solid ${c};margin:0">
          <div class="kpi-label">${l}</div>
          <div class="kpi-value" style="color:${c};font-size:17px">${v}</div>
        </div>`).join('')}
    </div>

    <!-- P&L bars & Return % -->
    <div class="row-2-equal">
      <div class="card">
        <div class="section-label">Unrealised P&amp;L per Holding</div>
        ${[...e].sort((a,b)=>b.pl-a.pl).map(h=>`
          <div class="pl-bar-row">
            <span class="pl-sym">${h.symbol.split('.')[0]}</span>
            <div class="pl-bar-wrap"><div class="pl-bar-fill" style="width:${(Math.abs(h.pl)/maxPL*100).toFixed(1)}%;background:${h.pl>=0?COLORS.green:COLORS.red}"></div></div>
            <span class="pl-val" style="color:${plCol(h.pl)}">${h.pl>=0?'+':'-'}${fmtLKR(Math.abs(h.pl))}</span>
          </div>`).join('')}
      </div>
      <div class="card">
        <div class="section-label">Return % by Holding</div>
        ${[...e].sort((a,b)=>b.plPct-a.plPct).map(h=>`
          <div class="pl-bar-row">
            <span class="pl-sym">${h.symbol.split('.')[0]}</span>
            <div class="pl-bar-wrap"><div class="pl-bar-fill" style="width:${(Math.abs(h.plPct)/maxPct*100).toFixed(1)}%;background:${h.plPct>=0?COLORS.green:COLORS.red}"></div></div>
            <span class="pl-val" style="color:${plCol(h.plPct)}">${pct(h.plPct)}</span>
          </div>`).join('')}
      </div>
    </div>

    <!-- Sector pie + trend -->
    <div class="row-2">
      <div class="card">
        <div class="section-label">30-Day Portfolio Trend (LKR)</div>
        <canvas id="chart-trend2" height="200"></canvas>
      </div>
      <div class="card">
        <div class="section-label">Sector Value (LKR)</div>
        <canvas id="chart-sector" height="200"></canvas>
      </div>
    </div>

    <!-- Portfolio Health -->
    <div class="card gold-top">
      <div class="section-label">Portfolio Health Score</div>
      ${[
        {icon:'✅',label:'Sectors Diversified',   val:`${sm.length} sectors`,         good:sm.length>=4},
        {icon:'✅',label:'Profitable Holdings',    val:`${e.filter(h=>h.pl>0).length} / ${e.length}`, good:e.filter(h=>h.pl>0).length>=e.length/2},
        {icon:'✅',label:'Largest Single Position',val:fmtLKR(Math.max(...e.map(h=>h.current))), good:true},
        {icon:'✅',label:'Total Holdings',         val:String(e.length), good:e.length>=5},
        {icon:'✅',label:'Average Return',         val:pct(t.plPct),     good:t.plPct>=0},
      ].map(r=>`
        <div class="health-row">
          <span class="health-icon">${r.good?'✅':'⚠️'}</span>
          <span class="health-label">${r.label}</span>
          <span class="health-value" style="color:${r.good?COLORS.green:COLORS.red}">${r.val}</span>
        </div>`).join('')}
    </div>
  `;

  // Trend chart
  makeChart('chart-trend2',{
    type:'line',
    data:{
      labels: HISTORY.map((_,i)=>i%5===0?`d${i+1}`:''),
      datasets:[{data:HISTORY,borderColor:'#a78bfa',backgroundColor:'rgba(167,139,250,0.07)',borderWidth:2,fill:true,tension:0.4,pointRadius:0}]
    },
    options:{
      responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>'රු.'+fmt(ctx.raw)},backgroundColor:'#0e1a2e',borderColor:'rgba(200,151,58,0.3)',borderWidth:1}},
      scales:{
        x:{grid:{color:'rgba(255,255,255,0.04)'},ticks:{color:COLORS.textMuted,font:{size:10}}},
        y:{grid:{color:'rgba(255,255,255,0.04)'},ticks:{color:COLORS.textMuted,font:{size:10},callback:v=>'M'+(v/1e6).toFixed(2)}},
      }
    }
  });

  // Sector horizontal bar
  makeChart('chart-sector',{
    type:'bar',
    data:{
      labels: sm.map(([s])=>s.length>16?s.slice(0,15)+'…':s),
      datasets:[{data:sm.map(([,v])=>v),backgroundColor:sm.map((_,i)=>PALETTE[i%PALETTE.length]),borderRadius:4}]
    },
    options:{
      indexAxis:'y',responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>'රු.'+fmt(ctx.raw)},backgroundColor:'#0e1a2e',borderColor:'rgba(200,151,58,0.3)',borderWidth:1}},
      scales:{
        x:{grid:{color:'rgba(255,255,255,0.04)'},ticks:{color:COLORS.textMuted,font:{size:9},callback:v=>'M'+(v/1e6).toFixed(1)}},
        y:{grid:{display:false},ticks:{color:COLORS.textSub,font:{size:9}}},
      }
    }
  });
}

// ── Add / Edit Modal ──────────────────────────────────────────────────────────
function openHoldingModal(holding) {
  const isEdit = !!holding;
  const h = holding || {id:'',symbol:'',name:'',qty:'',avgCost:'',cmp:'',sector:'Banks'};

  document.getElementById('modal-holding-box').innerHTML = `
    <div class="modal-header">
      <span class="modal-title">${isEdit?'Edit Holding':'Add CSE Holding'}</span>
      <button class="modal-close" id="mh-close">×</button>
    </div>
    <div class="form-grid-2">
      <div class="form-group">
        <label class="form-label">Ticker Symbol *</label>
        <input class="form-input" id="mh-symbol" placeholder="COMB.N0000" value="${h.symbol}">
      </div>
      <div class="form-group">
        <label class="form-label">Sector</label>
        <select class="form-select" id="mh-sector">
          ${CSE_SECTORS.map(s=>`<option value="${s}" ${h.sector===s?'selected':''}>${s}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Company Name</label>
      <input class="form-input" id="mh-name" placeholder="Commercial Bank of Ceylon PLC" value="${h.name}">
      <span class="form-hint">Ticker format: SYMBOL.N0000 (voting) · SYMBOL.X0000 (non-voting)</span>
    </div>
    <div class="form-grid-3">
      <div class="form-group">
        <label class="form-label">Quantity *</label>
        <input class="form-input" id="mh-qty" type="number" placeholder="200" value="${h.qty}">
      </div>
      <div class="form-group">
        <label class="form-label">Avg Cost (LKR) *</label>
        <input class="form-input" id="mh-cost" type="number" placeholder="112.00" value="${h.avgCost}">
      </div>
      <div class="form-group">
        <label class="form-label">CMP (LKR) *</label>
        <input class="form-input" id="mh-cmp" type="number" placeholder="128.50" value="${h.cmp}">
      </div>
    </div>
    <div id="mh-preview" class="preview-box" style="display:none">
      <div class="preview-title">PREVIEW</div>
      <div class="preview-row"><span class="preview-label">Invested</span><span class="preview-value" id="prev-inv"></span></div>
      <div class="preview-row"><span class="preview-label">Current</span><span class="preview-value" id="prev-cur"></span></div>
      <div class="preview-row"><span class="preview-label">Unrealised P&L</span><span class="preview-value" id="prev-pl"></span></div>
    </div>
    <div class="form-actions">
      <button class="btn-gold-full" id="mh-save">${isEdit?'Save Changes':'Add to Portfolio'}</button>
      <button class="btn-outline-full" id="mh-cancel">Cancel</button>
    </div>
  `;

  const overlay = document.getElementById('modal-holding');
  overlay.classList.add('open');

  // Live preview
  const updatePreview = () => {
    const qty=+document.getElementById('mh-qty').value;
    const cost=+document.getElementById('mh-cost').value;
    const cmp=+document.getElementById('mh-cmp').value;
    if(qty&&cost&&cmp) {
      const inv=qty*cost, cur=qty*cmp, pl=cur-inv;
      document.getElementById('prev-inv').textContent=fmtLKR(inv);
      document.getElementById('prev-cur').textContent=fmtLKR(cur);
      const plEl=document.getElementById('prev-pl');
      plEl.textContent=(pl>=0?'+':'-')+fmtLKR(Math.abs(pl));
      plEl.style.color=plCol(pl);
      document.getElementById('mh-preview').style.display='block';
    }
  };
  ['mh-qty','mh-cost','mh-cmp'].forEach(id=>document.getElementById(id)?.addEventListener('input',updatePreview));
  if(isEdit) updatePreview();

  document.getElementById('mh-close').onclick=()=>overlay.classList.remove('open');
  document.getElementById('mh-cancel').onclick=()=>overlay.classList.remove('open');
  document.getElementById('mh-save').onclick=()=>{
    const symbol=document.getElementById('mh-symbol').value.trim().toUpperCase();
    const qty=+document.getElementById('mh-qty').value;
    const avgCost=+document.getElementById('mh-cost').value;
    const cmp=+document.getElementById('mh-cmp').value;
    if(!symbol||!qty||!avgCost||!cmp){toast('⚠️ Please fill all required fields');return;}
    const rec={
      id: isEdit?h.id:uid(),
      symbol,
      name: document.getElementById('mh-name').value.trim()||symbol,
      qty, avgCost, cmp,
      sector: document.getElementById('mh-sector').value,
    };
    if(isEdit) holdings=holdings.map(x=>x.id===rec.id?rec:x);
    else holdings.push(rec);
    save();
    overlay.classList.remove('open');
    renderTab(activeTab);
    toast(isEdit?'✅ Holding updated':'✅ Holding added');
  };
}

// ── Update CMP Modal ──────────────────────────────────────────────────────────
function openCmpModal(id, currentCmp) {
  const h = holdings.find(x=>x.id===id);
  if(!h) return;
  document.getElementById('modal-cmp-box').innerHTML = `
    <div class="modal-header">
      <span class="modal-title">Update CMP</span>
      <button class="modal-close" id="mc-close">×</button>
    </div>
    <p style="font-size:11px;color:var(--text-sub);font-family:var(--font-mono);text-align:center;margin-bottom:12px">${h.symbol}</p>
    <input class="form-input" id="mc-cmp" type="number" value="${currentCmp}" style="text-align:center;font-size:18px;font-family:var(--font-mono)">
    <div class="form-actions" style="margin-top:14px">
      <button class="btn-gold-full" id="mc-save">Update</button>
      <button class="btn-outline-full" id="mc-cancel">Cancel</button>
    </div>
  `;
  const overlay=document.getElementById('modal-cmp');
  overlay.classList.add('open');
  document.getElementById('mc-cmp').focus();
  document.getElementById('mc-cmp').select();
  document.getElementById('mc-close').onclick=()=>overlay.classList.remove('open');
  document.getElementById('mc-cancel').onclick=()=>overlay.classList.remove('open');
  document.getElementById('mc-save').onclick=()=>{
    const cmp=+document.getElementById('mc-cmp').value;
    if(!cmp){toast('⚠️ Enter a valid CMP');return;}
    holdings=holdings.map(x=>x.id===id?{...x,cmp}:x);
    save(); overlay.classList.remove('open');
    renderTab(activeTab);
    toast('✅ CMP updated');
  };
  document.getElementById('mc-cmp').addEventListener('keydown',e=>{if(e.key==='Enter') document.getElementById('mc-save').click();});
}

// ── Delete ────────────────────────────────────────────────────────────────────
function deleteHolding(id) {
  if(!confirm('Remove this holding from your portfolio?')) return;
  holdings=holdings.filter(h=>h.id!==id);
  save(); renderHoldings(); toast('🗑️ Holding removed');
}

// ── CSV Import ────────────────────────────────────────────────────────────────
async function importCSV() {
  let csvText = null;

  if(window.electronAPI) {
    csvText = await window.electronAPI.openCsvDialog();
  }

  if(csvText===null) {
    // Fallback: show paste modal
    document.getElementById('modal-csv-box').innerHTML = `
      <div class="modal-header">
        <span class="modal-title">Import CSV</span>
        <button class="modal-close" id="mc2-close">×</button>
      </div>
      <div class="csv-hint">
        <div class="csv-hint-title">Expected Format:</div>
        <div class="csv-hint-code">symbol,name,qty,avgCost,cmp,sector
COMB.N0000,Commercial Bank of Ceylon PLC,200,112.00,128.50,Banks
JKH.N0000,John Keells Holdings PLC,100,195.00,218.75,Diversified Financials</div>
      </div>
      <textarea class="form-input csv-textarea" id="csv-text" placeholder="Paste CSV here…"></textarea>
      <div id="csv-preview-list" style="margin-top:10px;max-height:140px;overflow-y:auto"></div>
      <div class="form-actions" style="margin-top:14px">
        <button class="btn-outline-full" id="csv-preview-btn">Preview</button>
        <button class="btn-gold-full" id="csv-import-btn">Import</button>
      </div>
    `;
    const overlay=document.getElementById('modal-csv');
    overlay.classList.add('open');
    document.getElementById('mc2-close').onclick=()=>overlay.classList.remove('open');

    let parsed=[];
    document.getElementById('csv-preview-btn').onclick=()=>{
      parsed=parseCSV(document.getElementById('csv-text').value);
      document.getElementById('csv-preview-list').innerHTML=parsed.map(r=>`
        <div class="csv-preview-row">
          <span class="sym">${r.symbol}</span>
          <span class="qty">${r.qty} shares</span>
          <span class="cmp">CMP රු.${r.cmp}</span>
        </div>`).join('');
    };
    document.getElementById('csv-import-btn').onclick=()=>{
      if(!parsed.length) parsed=parseCSV(document.getElementById('csv-text').value);
      if(!parsed.length){toast('⚠️ No valid rows found');return;}
      holdings=[...holdings,...parsed];
      save(); overlay.classList.remove('open');
      renderTab(activeTab); toast(`✅ Imported ${parsed.length} holdings`);
    };
    return;
  }

  const rows=parseCSV(csvText);
  if(!rows.length){toast('⚠️ No valid rows found in CSV');return;}
  holdings=[...holdings,...rows];
  save(); renderTab(activeTab); toast(`✅ Imported ${rows.length} holdings`);
}

function parseCSV(text) {
  const lines=text.trim().split('\n').filter(Boolean);
  return lines.slice(1).map(l=>{
    const [symbol,name,qty,avgCost,cmp,sector]=l.split(',').map(s=>s.trim());
    return {id:uid(),symbol:symbol?.toUpperCase(),name:name||symbol,qty:+qty,avgCost:+avgCost,cmp:+cmp,sector:sector||'Banks'};
  }).filter(r=>r.symbol&&r.qty&&r.avgCost&&r.cmp);
}

// ── CSV Export ────────────────────────────────────────────────────────────────
async function exportCSV() {
  const header='symbol,name,qty,avgCost,cmp,sector';
  const rows=holdings.map(h=>`${h.symbol},${h.name},${h.qty},${h.avgCost},${h.cmp},${h.sector}`);
  const csv=[header,...rows].join('\n');

  if(window.electronAPI) {
    const ok=await window.electronAPI.saveCsvDialog(csv);
    if(ok) toast('✅ CSV exported successfully');
    return;
  }
  // Fallback download
  const blob=new Blob([csv],{type:'text/csv'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download=`CSE_Portfolio_${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  toast('✅ CSV downloaded');
}

// ── Bootstrap ─────────────────────────────────────────────────────────────────
async function init() {
  // Load Chart.js dynamically (bundled via node_modules path)
  await new Promise((res,rej)=>{
    const s=document.createElement('script');
    // Inline minimal Chart.js from CDN fallback via content-security-policy workaround
    // In production build, use local node_modules path
    s.src='https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js';
    s.onload=res; s.onerror=rej;
    document.head.appendChild(s);
  }).catch(()=>{
    // Offline fallback: define stub
    window.Chart = class { constructor(){} destroy(){} };
  });

  buildShell();
  await load();
  renderDashboard();
}

document.addEventListener('DOMContentLoaded', init);
