// src/preload.js  –  Secure context bridge
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  loadHoldings:    ()       => ipcRenderer.invoke('load-holdings'),
  saveHoldings:    (data)   => ipcRenderer.invoke('save-holdings', data),
  openCsvDialog:   ()       => ipcRenderer.invoke('open-csv-dialog'),
  saveCsvDialog:   (csv)    => ipcRenderer.invoke('save-csv-dialog', csv),

  onMenuImportCsv: (cb) => ipcRenderer.on('menu-import-csv', cb),
  onMenuExportCsv: (cb) => ipcRenderer.on('menu-export-csv', cb),
  onMenuTab:       (cb) => ipcRenderer.on('menu-tab', (_, tab) => cb(tab)),
});
