// src/main.js  –  Electron main process
const { app, BrowserWindow, ipcMain, dialog, Menu, shell } = require('electron');
const path = require('path');
const fs   = require('fs');

const isDev = process.argv.includes('--dev');

// ── Data persistence ──────────────────────────────────────────────────────────
const DATA_FILE = path.join(app.getPath('userData'), 'holdings.json');

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    }
  } catch (e) { console.error('Load error', e); }
  return null;
}

function saveData(data) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error('Save error', e);
    return false;
  }
}

// ── Window ────────────────────────────────────────────────────────────────────
let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width:  1280,
    height: 800,
    minWidth:  900,
    minHeight: 600,
    title: 'CSE Portfolio Manager',
    backgroundColor: '#080f1c',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
    titleBarStyle: 'hidden',
    titleBarOverlay: {
      color:       '#0a1220',
      symbolColor: '#C8973A',
      height: 36,
    },
    icon: path.join(__dirname, '..', 'assets', 'icon.ico'),
    show: false,
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());

  if (isDev) mainWindow.webContents.openDevTools();

  buildMenu();
}

// ── Menu ──────────────────────────────────────────────────────────────────────
function buildMenu() {
  const template = [
    {
      label: 'File',
      submenu: [
        { label: 'Import CSV…',    accelerator: 'CmdOrCtrl+O', click: () => mainWindow.webContents.send('menu-import-csv') },
        { label: 'Export CSV…',    accelerator: 'CmdOrCtrl+E', click: () => mainWindow.webContents.send('menu-export-csv') },
        { type: 'separator' },
        { label: 'Quit',           accelerator: 'CmdOrCtrl+Q', role: 'quit' },
      ],
    },
    {
      label: 'View',
      submenu: [
        { label: 'Dashboard',  accelerator: 'CmdOrCtrl+1', click: () => mainWindow.webContents.send('menu-tab', 'dashboard') },
        { label: 'Holdings',   accelerator: 'CmdOrCtrl+2', click: () => mainWindow.webContents.send('menu-tab', 'holdings') },
        { label: 'Analytics',  accelerator: 'CmdOrCtrl+3', click: () => mainWindow.webContents.send('menu-tab', 'analytics') },
        { type: 'separator' },
        { label: 'Reload',     accelerator: 'CmdOrCtrl+R', role: 'reload' },
        { label: 'Toggle DevTools', accelerator: 'F12', role: 'toggleDevTools' },
        { type: 'separator' },
        { label: 'Zoom In',    accelerator: 'CmdOrCtrl+=', role: 'zoomIn' },
        { label: 'Zoom Out',   accelerator: 'CmdOrCtrl+-', role: 'zoomOut' },
        { label: 'Reset Zoom', accelerator: 'CmdOrCtrl+0', role: 'resetZoom' },
        { label: 'Fullscreen', accelerator: 'F11', role: 'togglefullscreen' },
      ],
    },
    {
      label: 'Help',
      submenu: [
        { label: 'Visit CSE Website', click: () => shell.openExternal('https://www.cse.lk') },
        { label: 'About CSE Portfolio', click: () => {
          dialog.showMessageBox(mainWindow, {
            type: 'info',
            title: 'About CSE Portfolio',
            message: 'CSE Portfolio Manager v1.0.0',
            detail: 'A desktop portfolio tracker for the Colombo Stock Exchange.\n\nBuilt for Sri Lankan investors.\n\nData stored locally on your computer.',
            icon: path.join(__dirname, '..', 'assets', 'icon.ico'),
          });
        }},
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ── IPC handlers ──────────────────────────────────────────────────────────────
ipcMain.handle('load-holdings',  () => loadData());
ipcMain.handle('save-holdings',  (_, data) => saveData(data));

ipcMain.handle('open-csv-dialog', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Import Holdings CSV',
    filters: [{ name: 'CSV Files', extensions: ['csv'] }],
    properties: ['openFile'],
  });
  if (result.canceled || !result.filePaths.length) return null;
  return fs.readFileSync(result.filePaths[0], 'utf8');
});

ipcMain.handle('save-csv-dialog', async (_, csvContent) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Export Holdings CSV',
    defaultPath: `CSE_Portfolio_${new Date().toISOString().slice(0,10)}.csv`,
    filters: [{ name: 'CSV Files', extensions: ['csv'] }],
  });
  if (result.canceled || !result.filePath) return false;
  fs.writeFileSync(result.filePath, csvContent, 'utf8');
  return true;
});

// ── App lifecycle ─────────────────────────────────────────────────────────────
app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
