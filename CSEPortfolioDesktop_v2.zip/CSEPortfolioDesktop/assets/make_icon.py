#!/usr/bin/env python3
"""Generate a simple CSE Portfolio icon (ICO format) for Windows."""
import struct, zlib, io, os

def make_png_bytes(size, bg, fg):
    """Create a minimal PNG with CSE colors."""
    import struct, zlib
    w = h = size

    # Create raw pixel data (RGBA)
    pixels = []
    cx, cy, r = w//2, h//2, w//2 - 2
    for y in range(h):
        for x in range(w):
            dx, dy = x - cx, y - cy
            dist = (dx*dx + dy*dy) ** 0.5
            if dist <= r:
                # Inside circle: navy bg
                pixels += [0x00, 0x30, 0x87, 255]
            else:
                pixels += [0, 0, 0, 0]  # transparent

    # Draw "₹" symbol roughly in gold
    for y in range(h//4, 3*h//4):
        for x in range(w//4, 3*w//4):
            dy = y - cy
            dx = x - cx
            # Simple cross pattern for chart icon
            if abs(dx) < w//16 or abs(dy) < h//16:
                idx = (y * w + x) * 4
                pixels[idx]   = 0xC8  # gold R
                pixels[idx+1] = 0x97  # gold G
                pixels[idx+2] = 0x3A  # gold B
                pixels[idx+3] = 255

    raw = b''
    for y in range(h):
        raw += b'\x00'  # filter type none
        for x in range(w):
            i = (y*w+x)*4
            raw += bytes(pixels[i:i+4])

    def chunk(name, data):
        c = name + data
        return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)

    compressed = zlib.compress(raw, 9)
    ihdr_data = struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)  # RGB without alpha, then fix
    ihdr_data = struct.pack('>II', w, h) + bytes([8, 6, 0, 0, 0])  # RGBA

    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', ihdr_data)
    png += chunk(b'IDAT', compressed)
    png += chunk(b'IEND', b'')
    return png

def make_ico(output_path):
    sizes = [16, 32, 48, 64, 128, 256]
    images = []
    for size in sizes:
        png = make_png_bytes(size, (0x00, 0x30, 0x87), (0xC8, 0x97, 0x3A))
        images.append((size, png))

    # ICO header
    header = struct.pack('<HHH', 0, 1, len(images))  # reserved, type=1(ICO), count

    # Directory entries (each 16 bytes)
    offset = 6 + 16 * len(images)
    dir_entries = b''
    for size, png in images:
        w = h = size if size < 256 else 0
        dir_entries += struct.pack('<BBBBHHII',
            w, h,           # width, height (0 = 256)
            0,              # color count (0 = > 8bpp)
            0,              # reserved
            1,              # planes
            32,             # bit count
            len(png),       # size of image data
            offset          # offset of image data
        )
        offset += len(png)

    with open(output_path, 'wb') as f:
        f.write(header + dir_entries)
        for _, png in images:
            f.write(png)
    print(f"Icon saved: {output_path} ({os.path.getsize(output_path)} bytes)")

if __name__ == '__main__':
    out = os.path.join(os.path.dirname(__file__), 'icon.ico')
    make_ico(out)
