; assets/installer.nsh
; Custom NSIS installer branding for CSE Portfolio

!macro customHeader
  !system "echo Building CSE Portfolio Installer..."
!macroend

!macro customInstall
  ; Create registry entry for uninstall info
  WriteRegStr HKCU "Software\CSEPortfolio" "InstallPath" "$INSTDIR"
!macroend

!macro customUnInstall
  DeleteRegKey HKCU "Software\CSEPortfolio"
!macroend
